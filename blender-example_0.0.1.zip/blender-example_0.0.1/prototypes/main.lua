local function sprite(name)
    return '__blender-example__/ressources/'..name..'.png'
end

local function make_item(height, width)
    local table = {
        name = '1x1_item',
        type = 'item',
        icon = sprite('1x1_item'),
        icon_size = 64,
        place_result = '1x1_entity',
        stack_size = 20,
        subgroup = 'storage',
        order = 'a-a'
    }
    table.name = tostring(height)..'x'..tostring(width)..'_item'
    table.icon = sprite(table.name)
    table.place_result = tostring(height)..'x'..tostring(width)..'_entity'
    data:extend({table})
end

local function make_entity(height, width)
    local table = {
        name = '1x1_entity',
        type = 'container',
        icon = sprite('1x1_item'),
        icon_size = 64,
        selection_box = {{-1, -1}, {1, 1}},
        picture = {
            filename = sprite('1x1_picture'),
            width = 256,
            height = 256
        },
        inventory_size = 1
    }
    table.name = tostring(height)..'x'..tostring(width)..'_entity'
    table.icon = sprite(tostring(height)..'x'..tostring(width)..'_item')
    table.selection_box = {{-height/2, -width/2},{height/2, width/2}}
    table.collision_box = {{-height/2+0.2, -width/2+0.2},{height/2-0.2, width/2-0.2}}
    table.picture = {
        filename = sprite(tostring(height)..'x'..tostring(width)..'_picture'),
        width = 256,
        height = 256,
        shift = {0,-0.75}
    }
    table.minable = {
        mining_time = 1,
        result = tostring(height)..'x'..tostring(width)..'_item'
    },
    data:extend({table})
end

local function make_recipe(height, width)
    local table = {
        name = '1x1_recipe',
        type = 'recipe',
        enabled = true,
        ingredients = {},
        result = '1x1_item',
        result_count = 1,
        energy_required = 0.1,
        order = 'a',
    }
    table.name = tostring(height)..'x'..tostring(width)..'_recipe'
    table.result = tostring(height)..'x'..tostring(width)..'_item'
    data:extend({table})
end

local function make_prototype(height, width)
    make_item(height, width)
    make_entity(height, width)
    make_recipe(height, width)
end

--=======================================================
-- make prototypes
--======================================================

local sizes = {
    {3,5},
    {3,3},
    {2,2},
    {1,1}
}

for i,v in pairs(sizes) do 
    make_prototype(v[1],v[2])
end

