local spritter = require("spritter_util")

local wagon = data.raw["cargo-wagon"]["cargo-wagon"]

---@param a Vector
---@param b Vector
---@return Vector
function shift_add(a, b)
    local x = (a.x or a[1]) + (b.x or b[1])
    local y = (a.y or a[2]) + (b.y or b[2])
    return { x, y }
end

---@param path string
---@return data.RotatedSprite
function rotated_sprite(path)
    local offset = { 0, 0 }
    local meta = spritter.get_metadata(path)

    return {
        filenames = spritter.get_filenames(meta),
        shift = shift_add(meta.shift, offset),
        scale = meta.scale,
        width = meta.width,
        height = meta.height,
        line_length = meta.line_length,
        lines_per_file = meta.lines_per_file,
        direction_count = meta.sprite_count,

        priority = "very-low",
        usage = "train",
        dice = 4,
    }
end

---@type data.CargoWagonPrototype
local susanne = {
    type = "cargo-wagon",
    name = "susanne",
    icon = "__susanne__/graphics/icon.png",
    icon_size = 64,

    inventory_size = 1,
    air_resistance = 0.01,
    friction_force = 0.5,
    braking_force = 3,
    max_speed = 1.5,
    joint_distance = 4,
    connection_distance = 3,
    vertical_selection_shift = -0.8,
    energy_per_hit_point = 5,
    weight = 1000,

    -- luals / fmtk are unaware of the
    -- required energy/force constraint
    braking_power = nil,
    friction = nil,

    resistances = wagon.resistances,
    flags = wagon.flags,
    dying_explosion = wagon.dying_explosion,
    color = wagon.color,
    collision_box = wagon.collision_box,
    selection_box = wagon.selection_box,
    minimap_representation = wagon.minimap_representation,
    selected_minimap_representation = wagon.selected_minimap_representation,
    drive_over_elevated_tie_trigger = wagon.drive_over_elevated_tie_trigger,
    drive_over_tie_trigger = wagon.drive_over_tie_trigger,
    drive_over_tie_trigger_minimal_speed = wagon.drive_over_tie_trigger_minimal_speed,
    mined_sound = wagon.mined_sound,
    open_sound = wagon.open_sound,
    close_sound = wagon.close_sound,
    wheels = wagon.wheels,
    working_sound = wagon.working_sound,
    water_reflection = wagon.water_reflection,
    door_opening_sound = wagon.door_opening_sound,
    door_closing_sound = wagon.door_closing_sound,
    corpse = wagon.corpse,

    pictures = {
        slope_angle_between_frames = 1.25,
        slope_back_equals_front = false,
        rotated = rotated_sprite("__susanne__/graphics/susanne"),
        sloped = rotated_sprite("__susanne__/graphics/susanne_sloped"),
    },

    minable = {
        mining_time = 1,
        result = "susanne",
    }
}

---@type data.ItemPrototype
local item = {
    type = "item",
    name = "susanne",
    icon = "__susanne__/graphics/icon.png",
    icon_size = 64,
    subgroup = "train-transport",
    order = "c[rolling-stock]-b[susanne]",
    place_result = "susanne",
    stack_size = 5,
}

---@type data.RecipePrototype
local recipe = {
    type = "recipe",
    name = "susanne",
    enabled = true,
    ingredients = {
        { type = "item", name = "iron-gear-wheel", amount = 10 },
        { type = "item", name = "iron-plate",      amount = 20 },
        { type = "item", name = "steel-plate",     amount = 10 },
    },
    results = {
        { type = "item", name = "susanne", amount = 1 },
    },
}

data:extend({ susanne, item, recipe })
