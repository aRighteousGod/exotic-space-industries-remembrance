local lib = {}

---@alias Version {[1]:uint,[2]:uint,[3]:uint}

---@class ExportedMetadata
---@field spritter? Version Spritter version used to generate the metadata
---@field path string Path used to fetch the metadata

---@class Metadata: ExportedMetadata
---@field width uint
---@field height uint
---@field shift Vector
---@field scale number
---@field sprite_count uint
---@field line_length uint
---@field lines_per_file uint
---@field file_count? uint
---@field frame_sequence? uint[]

---@class SSSLMetadata: ExportedMetadata
---@field single_sheet_split_layers Metadata[]

---@alias SpritterMetadata Metadata|SSSLMetadata

---@param version Version
function check_version(version)
    local major, minor, patch = version[1], version[2], version[3]
    if major ~= 1 then
        return false
    end

    if minor < 8 then
        return false
    end

    if minor == 8 and patch < 1 then
        return false
    end

    return true
end

---@param path string Path to the spritter metadata lua file next to the image file(s)
---@return SpritterMetadata
function lib.get_metadata(path)
    local metadata = require(path) --[[@as SpritterMetadata]]
    metadata.path = path

    if not metadata or not metadata.spritter then
        error("Invalid spritter metadata file: " .. path)
    end

    local version = metadata.spritter --[[@cast version -?]]
    if not check_version(version) then
        error("Unsupported spritter version: " .. table.concat(version, "."))
    end

    return metadata
end

---@param metadata SpritterMetadata
---@return string[]
function lib.get_filenames(metadata)
    local filenames = {}
    local count = metadata.file_count or 1
    for i = 0, count - 1 do
        local name = metadata.path .. "-" .. i .. ".png"
        table.insert(filenames, name)
    end

    return filenames
end

return lib
