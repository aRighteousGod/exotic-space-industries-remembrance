import os
import sys
from PIL import Image

def process_image(file_path):
    # Open the image and convert it to RGBA
    img = Image.open(file_path).convert('RGBA')
    
    # Save the processed image in the same location with 8-bit depth
    img.save(file_path, 'PNG', bitdepth=8)
    print(f"Processed and saved {file_path}")

if __name__ == "__main__":
    # Check whether the script is executed with at least one file as argument
    if len(sys.argv) < 2:
        input("Please drag and drop at least one file onto the script.")
        sys.exit(1)
    
    # Process each transferred file
    for input_file in sys.argv[1:]:
        if os.path.isfile(input_file) and input_file.endswith('.png'):
            print(f"Processing file: {input_file}")
            process_image(input_file)
        else:
            input(f"{input_file} is not a valid PNG file. Skipping...")
