import os
import sys
from PIL import Image

def process_images(directory):
    # Extract the name of the origin folder
    parent_dir, source_folder_name = os.path.split(os.path.abspath(directory))
    
    # Create the new name of the origin folder with “ OG” suffix
    new_source_folder_name = f"{source_folder_name} OG"
    new_source_dir = os.path.join(parent_dir, new_source_folder_name)
    
    # Rename the origin folder
    os.rename(directory, new_source_dir)
    
    # Create the name of the destination folder (like the original before renaming)
    output_folder_name = source_folder_name
    output_dir = os.path.join(parent_dir, output_folder_name)
    
    # Create the destination folder if it does not exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get all PNG files in the renamed directory (ignore subdirectories)
    images = [f for f in os.listdir(new_source_dir) if f.endswith('.png') and os.path.isfile(os.path.join(new_source_dir, f))]
    
    # Sort the images to ensure the correct order
    images.sort()
    
    # Process each image
    for image_name in images:
        img_path = os.path.join(new_source_dir, image_name)
        img = Image.open(img_path).convert('RGBA')
        
        # Process the image: replace fully transparent pixels with black
        width, height = img.size
        pixels = img.load()
        
        for y in range(height):
            for x in range(width):
                r, g, b, a = pixels[x, y]
                # Convert 1/255 to 1 (since 1/255 in 8-bit color is approximately 1)
                if a == 0:
                    pixels[x, y] = (0, 0, 0, 0)
                    continue
                if r == 0 and g == 0 and b == 0:
                    pixels[x, y] = (0, 0, 0, 0)
        
        # Speichere das verarbeitete Bild im Zielordner mit 8-Bit-Tiefe
        output_path = os.path.join(output_dir, image_name)
        img.save(output_path, 'PNG', bitdepth=8)
        print(f"Processed and saved {output_path}")

if __name__ == "__main__":
    # Check whether the script is executed with at least one directory as argument
    if len(sys.argv) < 2:
        print("Please drag and drop at least one directory onto the script.")
        sys.exit(1)
    
    # Process each transferred directory
    for input_directory in sys.argv[1:]:
        if os.path.isdir(input_directory):
            print(f"Processing directory: {input_directory}")
            process_images(input_directory)
        else:
            print(f"{input_directory} is not a valid directory. Skipping...")
