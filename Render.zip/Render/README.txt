_16to8 RGBA Folder.py
- drag folders
- transfers originals to "[...] OG" folder
- X-bit RGBA to 8-bit RGBA

_16to8 RGBA Single.py
- drag single files
- originals will be overwritten!
- X-bit RGBA to 8-bit RGBA

_Black to Transparent.py
- drag folders
- transfers originals to "[...] OG" folder
- makes black pixels transparent
- nulls color values of transparent pixels (saves space)
- X-bit RGBA to 8-bit RGBA

_SpriteSheet v2.py
- just open
- options should be obvious
- last three buttons automatically create YxY spritesheets from selected images