from PIL import Image
import tkinter as tk
from tkinter import filedialog

def clear_selected_images():
    # Clear the input_images list
    input_images.clear()

    # Clear the listbox
    selected_files_listbox.delete(0, tk.END)

def create_tiled_images(input_images, grid_size, base_filename):
    
    #Creates multiple spritesheets from the list of images and saves them with count suffixes.
    #:param input_images: List of image file paths
    #:param grid_size: Tuple (columns, rows) for the spritesheet size
    #:param base_filename: Base name for the output files (suffix is added automatically)
    
    # Number of images per spritesheet
    images_per_sheet = grid_size[0] * grid_size[1]
    
    # Calculate number of spritesheets
    total_images = len(input_images)
    num_sheets = (total_images + images_per_sheet - 1) // images_per_sheet  # Rundet auf
    
    for sheet_index in range(num_sheets):
        # Calculation of the images for the current spritesheet
        start_index = sheet_index * images_per_sheet
        end_index = min(start_index + images_per_sheet, total_images)
        current_images = input_images[start_index:end_index]
        
        # Calculate the size of the output image
        output_size = (grid_size[0] * tile_width, grid_size[1] * tile_height)
        output_image = Image.new('RGBA', output_size)
        
        # Insert images into the spritesheet
        for i, image_path in enumerate(current_images):
            row = i // grid_size[0]
            col = i % grid_size[0]
            x = col * tile_width
            y = row * tile_height
            
            # Open image and scale to tile size
            tile_image = Image.open(image_path).convert('RGBA')
            tile_image = tile_image.resize((tile_width, tile_height))
            
            # Insert image
            output_image.paste(tile_image, (x, y))
        
        # Generate output file names
        output_filename = f"{base_filename}_{sheet_index}.png"
        
        # Save spritesheet
        output_image.save(output_filename)
        print(f"Spritesheet gespeichert: {output_filename}")

def create_tiled_image(input_images, grid_size, output_filename):
    # Calculate the size of each tile
    output_size = (grid_size[0] * tile_width, grid_size[1] * tile_height)

    # Create a blank image for the output with RGBA mode
    output_image = Image.new('RGBA', output_size)

    # Iterate over each tile in the grid
    for row in range(grid_size[1]):
        for col in range(grid_size[0]):
            # Calculate the position of the current tile
            x = col * tile_width
            y = row * tile_height

            # Get the image index from the input_images list
            image_index = (row * grid_size[0] + col) % len(input_images)

            # Open the image and resize it to fit the tile
            tile_image = Image.open(input_images[image_index]).convert('RGBA')
            tile_image = tile_image.resize((tile_width, tile_height))

            # Paste the tile onto the output image
            output_image.paste(tile_image, (x, y))

    # Save or display the resulting image
    output_image.save(output_filename)

def open_file_dialog():
    file_paths = filedialog.askopenfilenames()
    input_images.extend(file_paths)
    
    # Open the first image and get its size
    global tile_width, tile_height
    with Image.open(file_paths[0]) as img:
        tile_width, tile_height = img.size

    # Clear the listbox before updating with the selected file names
    selected_files_listbox.delete(0, tk.END)
    
    # Update the listbox with the selected file names
    for file_path in input_images:
        selected_files_listbox.insert(tk.END, file_path)

def reverse_order_images():
    input_images.reverse()
    selected_files_listbox.delete(0, tk.END)
    for file_path in input_images:
        selected_files_listbox.insert(tk.END, file_path)

def create_tiled_image_gui():
    global selected_files_listbox  # Define the listbox in global scope
    
    root = tk.Tk()
    root.title("Tiled Image Creator")

    root.configure(background="#1e1e1e")
    root.minsize(300, 200)

    # Create grid size input
    grid_size_label = tk.Label(root, text="Grid Size (rows, columns):")
    grid_size_label.pack()
    grid_size_entry = tk.Entry(root)
    grid_size_entry.pack()

    # Create image selection button
    select_image_button = tk.Button(root, text="Select Images", command=open_file_dialog)
    select_image_button.pack()

    # Create scrollbar
    scrollbar = tk.Scrollbar(root)
    scrollbar.configure(background="#1e1e1e")
    
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    

    # Create listbox for selected files
    selected_files_listbox = tk.Listbox(root, yscrollcommand=scrollbar.set)
    selected_files_listbox.pack(fill=tk.BOTH, expand=True)

    # Configure the scrollbar to work with the listbox
    scrollbar.config(command=selected_files_listbox.yview)

    # Create output file name input
    output_filename_label = tk.Label(root, text="Output File Name:")
    output_filename_label.pack()
    output_filename_entry = tk.Entry(root)
    output_filename_entry.pack()

    # Create create button
    def create_button_click():
        grid_size = tuple(map(int, grid_size_entry.get().split(',')))
        output_filename = output_filename_entry.get() + ".png"
        create_tiled_image(input_images, grid_size, output_filename)

    # Create clear selected images button
    clear_button = tk.Button(root, text="Clear Selected Images", command=clear_selected_images)
    clear_button.pack()
    
    create_button = tk.Button(root, text="Create Tiled Image", command=create_button_click)
    create_button.pack()
    
    def setPreset(size):
        grid_size_entry.delete(0, tk.END)
        grid_size_entry.insert(0, size)
        
        grid_size = tuple(map(int, grid_size_entry.get().split(',')))
        create_tiled_images(input_images, grid_size, output_filename_entry.get())
    
    matrix1 = tk.Button(root, text="2x2", command=lambda: setPreset("2,2"))
    matrix1.pack()
    matrix2 = tk.Button(root, text="4x4", command=lambda: setPreset("4,4"))
    matrix2.pack()
    matrix3 = tk.Button(root, text="8x8", command=lambda: setPreset("8,8"))
    matrix3.pack()

    # Create reverse order button
    #reverse_button = tk.Button(root, text="Reverse Order", command=reverse_order_images)
    #reverse_button.pack()

    # Set the background color of grid_size_entry
    grid_size_entry.configure(background="#1e1e1e", fg="white")
    grid_size_label.configure(background="#1e1e1e", fg="white")
    output_filename_label.configure(background="#1e1e1e", fg="white")
    select_image_button.configure(background="#1e1e1e", fg="white")
    selected_files_listbox.configure(background="#1e1e1e", fg="white")
    output_filename_entry.configure(background="#1e1e1e", fg="white")
    create_button.configure(background="#1e1e1e", fg="white")
    clear_button.configure(background="#1e1e1e", fg="white")
    #reverse_button.configure(background="#1e1e1e", fg="white")

    root.mainloop()

# Example usage
input_images = []
global tile_width 
global tile_height 
create_tiled_image_gui()