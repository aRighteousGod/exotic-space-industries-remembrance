--====================================================================================================
--TILES FOR GAIA
--====================================================================================================

local grass_variant_weights = {
    max_size = 4,
    [1] = {weights = {0.085, 0.085, 0.085, 0.085, 0.087, 0.085, 0.065, 0.085, 0.045, 0.045, 0.045, 0.045, 0.005, 0.025, 0.045, 0.045}},
    [2] = {probability = 0.91, weights = {0.15, 0.15, 0.15, 0.15, 0.018, 0.02, 0.015, 0.025, 0.015, 0.02, 0.025, 0.015, 0.025, 0.025, 0.01, 0.025}},
    [4] = {probability = 0.82, weights = {0.1, 0.08, 0.08, 0.1, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01}},
}

local rock_variant_weights = {
    max_size = 4,
    [1] = {weights = {0.085, 0.085, 0.085, 0.085, 0.087, 0.085, 0.065, 0.085, 0.045, 0.045, 0.045, 0.045, 0.005, 0.025, 0.045, 0.045}},
    [2] = {probability = 1, weights = {0.07, 0.07, 0.025, 0.07, 0.07, 0.07, 0.007, 0.025, 0.07, 0.05, 0.015, 0.026, 0.03, 0.005, 0.07, 0.027}},
    [4] = {probability = 1, weights = {0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.015, 0.07, 0.07, 0.07, 0.015, 0.05, 0.07, 0.07, 0.065, 0.07}},
}

local function make_gaia_tile(definition)
    local base_tile = data.raw.tile[definition.base_tile]
    local transition_tile = data.raw.tile[definition.transition_tile or definition.base_tile]

    return {
        name = definition.name,
        type = "tile",
        order = definition.order,
        collision_mask = {layers = {ground_tile = true}},
        layer = definition.layer,
        variants = tile_variations_template(
            ei_graphics_terrain_path .. definition.texture,
            definition.mask,
            definition.variant_weights
        ),
        transitions = transition_tile.transitions,
        transitions_between_transitions = transition_tile.transitions_between_transitions,
        autoplace = {probability_expression = definition.probability_expression},
        walking_sound = base_tile.walking_sound,
        map_color = definition.map_color,
        scorch_mark_color = base_tile.scorch_mark_color or {r = 0.318, g = 0.222, b = 0.152, a = 1},
        pollution_absorption_per_second = base_tile.pollution_absorption_per_second,
        vehicle_friction_modifier = base_tile.vehicle_friction_modifier,
        trigger_effect = base_tile.trigger_effect,
    }
end

data:extend({
    make_gaia_tile({
        name = "ei-gaia-grass-1",
        base_tile = "grass-1",
        transition_tile = "grass-1",
        texture = "gaia-grass-1_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-3.png",
        variant_weights = grass_variant_weights,
        order = "a[gaia]-a[grass]",
        layer = 55,
        probability_expression = "clamp(0.08 + 3.2 * gaia_meadow_mask * gaia_select(gaia_variant_noise, -1, 0.64, 0.18, 0, 1), 0, 3.5)",
        map_color = {r = 0.184, g = 0.207, b = 0.027},
    }),
    make_gaia_tile({
        name = "ei-gaia-grass-2",
        base_tile = "grass-2",
        transition_tile = "grass-2",
        texture = "gaia-grass-2_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-3.png",
        variant_weights = grass_variant_weights,
        order = "a[gaia]-a[grass]",
        layer = 56,
        probability_expression = "clamp(0.1 + 3.3 * gaia_wet_mask * gaia_select(gaia_variant_noise, -1, 0.72, 0.16, 0, 1), 0, 3.6)",
        map_color = {r = 0.215, g = 0.207, b = 0.04},
    }),
    make_gaia_tile({
        name = "ei-gaia-grass-1-var",
        base_tile = "grass-1",
        transition_tile = "grass-1",
        texture = "gaia-grass-1_var_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-3.png",
        variant_weights = grass_variant_weights,
        order = "a[gaia]-a[grass]",
        layer = 57,
        probability_expression = "clamp(1.6 * gaia_meadow_mask * gaia_select(gaia_variant_noise, 0.62, 1.1, 0.12, 0, 1), 0, 1.6)",
        map_color = {r = 0.235, g = 0.207, b = 0.05},
    }),
    make_gaia_tile({
        name = "ei-gaia-grass-2-var",
        base_tile = "grass-2",
        transition_tile = "grass-2",
        texture = "gaia-grass-2_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-3.png",
        variant_weights = grass_variant_weights,
        order = "a[gaia]-a[grass]",
        layer = 58,
        probability_expression = "0",
        map_color = {r = 0.215, g = 0.274, b = 0.04},
    }),
    make_gaia_tile({
        name = "ei-gaia-grass-2-var-2",
        base_tile = "grass-2",
        transition_tile = "grass-2",
        texture = "gaia-grass-2_var_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-3.png",
        variant_weights = grass_variant_weights,
        order = "a[gaia]-a[grass]",
        layer = 59,
        probability_expression = "clamp(1.45 * gaia_wet_mask * gaia_select(gaia_variant_noise, 0.7, 1.1, 0.1, 0, 1), 0, 1.5)",
        map_color = {r = 0.149, g = 0.247, b = 0.06},
    }),
    make_gaia_tile({
        name = "ei-gaia-rock-1",
        base_tile = "dirt-4",
        transition_tile = "grass-3",
        texture = "gaia-rock-1_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-1.png",
        variant_weights = rock_variant_weights,
        order = "a[gaia]-a[rock]",
        layer = 60,
        probability_expression = "clamp(0.08 + 2.8 * gaia_rock_fringe_mask * gaia_select(gaia_variant_noise, -1, 0.78, 0.16, 0, 1), 0, 3.1)",
        map_color = {r = 0.49, g = 0.34, b = 0.2},
    }),
    make_gaia_tile({
        name = "ei-gaia-rock-2",
        base_tile = "dry-dirt",
        transition_tile = "dry-dirt",
        texture = "gaia-rock-2_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-1.png",
        variant_weights = rock_variant_weights,
        order = "a[gaia]-a[rock]",
        layer = 61,
        probability_expression = "clamp(0.05 + 2.3 * gaia_rock_core_mask * gaia_select(gaia_variant_noise, -1, 0.5, 0.18, 0, 1), 0, 2.6)",
        map_color = {r = 0.65, g = 0.305, b = 0.09},
    }),
    make_gaia_tile({
        name = "ei-gaia-rock-3",
        base_tile = "dirt-3",
        transition_tile = "dirt-3",
        texture = "gaia-rock-3_hr.png",
        mask = "__base__/graphics/terrain/masks/transition-1.png",
        variant_weights = rock_variant_weights,
        order = "a[gaia]-a[rock]",
        layer = 62,
        probability_expression = "clamp(0.05 + 2.1 * gaia_rock_core_mask * gaia_select(gaia_variant_noise, 0.45, 1.1, 0.16, 0, 1), 0, 2.5)",
        map_color = {r = 0.368, g = 0.168, b = 0.05},
    }),
})
