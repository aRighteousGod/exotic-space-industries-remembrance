
local planet_map_gen = require("__space-age__/prototypes/planet/planet-map-gen")
local gaia_biomes = require("gaia-biomes")
local gaia_decorative_settings = require("gaia-decoratives")

local gaia_patch_controls = {
    ["ei-morphium-patch"] = {frequency = 3, size = 1, richness = 1},
    ["ei-phytogas-patch"] = {frequency = 3, size = 1, richness = 1},
    ["ei-cryoflux-patch"] = {frequency = 3, size = 1, richness = 1},
    ["ei-ammonia-patch"] = {frequency = 3, size = 1, richness = 1},
    ["ei-coal-gas-patch"] = {frequency = 3, size = 1, richness = 1},
    ["scrap"] = {frequency = 0.05, richness = 0.05, size = 0.05},
}

local gaia_entity_settings = table.deepcopy(gaia_patch_controls)
gaia_entity_settings["ei-gaia-tree-01"] = {frequency = 2.7, richness = 1, size = 1.45}
gaia_entity_settings["ei-gaia-tree-02"] = {frequency = 2.9, richness = 1, size = 1.55}
gaia_entity_settings["ei-gaia-tree-05"] = {frequency = 1.15, richness = 1, size = 1.05}
gaia_entity_settings["ei-gaia-boulder-big"] = {frequency = 0.28, richness = 1, size = 0.5}
gaia_entity_settings["ei-gaia-crystal-boulder"] = {frequency = 0.08, richness = 1, size = 0.25}

local gaia_tile_groups = gaia_biomes.tile_groups

local gaia_tile_settings = {}

for _, tile_group in pairs(gaia_biomes.primary_tile_groups) do
    for _, tile_name in ipairs(tile_group) do
        gaia_tile_settings[tile_name] = {frequency = 1, richness = 1, size = 1}
    end
end

data:extend({
    {
    type = "autoplace-control",
    name = "gaia_cliff",
    order = "g-a-i-a",
    category = "cliff",
    richness = true,
  },
})

local function build_gaia_autoplace_controls()
    local autoplace_controls = table.deepcopy(gaia_patch_controls)
    autoplace_controls["gaia_cliff"] = {}
    return autoplace_controls
end

local function build_gaia_autoplace_settings()
    return {
        entity = {settings = table.deepcopy(gaia_entity_settings)},
        decorative = {settings = table.deepcopy(gaia_decorative_settings)},
        tile = {settings = table.deepcopy(gaia_tile_settings)},
    }
end

planet_map_gen.gaia = function ()
    local map_gen_settings = {
        default_enable_all_autoplace_controls = false,
        terrain_segmentation = 0.55,
        water = "ei-gaia-water",
        autoplace_controls = build_gaia_autoplace_controls(),
        autoplace_settings = build_gaia_autoplace_settings(),
        cliff_settings = {
            name = "cliff-gaia",
            control = "gaia_cliff",
            cliff_elevation_0 = 24,
            cliff_elevation_interval = 80,
            richness = 0.2,
            cliff_smoothing = 0.5,
        },
        property_expression_names = {
            -- Gaia keeps its own climate fields, but they are now anchored on the stable
            -- vanilla basics and then biased by Gaia's biome masks so fresh chunks keep
            -- leafy trees without losing Gaia-specific climate shaping.
            aux = "gaia_aux",
            cliff_elevation = "cliff_elevation_from_elevation",
            cliffiness = "gaia_cliffiness",
            elevation = "gaia_elevation",
            moisture = "gaia_moisture",
            temperature = "gaia_temperature",
        }
    }

    if mods["Electric_flying_enemies"] then
        map_gen_settings.no_enemies_mode = false
        map_gen_settings.autoplace_controls["electric_enemies"] = {frequency = 1, richness = 1, size = 5}
        map_gen_settings.autoplace_settings.entity.settings["flying-electric-unit-spawner"] = {}
        map_gen_settings.autoplace_settings.entity.settings["walker-electric-unit-spawner"] = {}
    end

    return map_gen_settings
end

planet_map_gen.gaia_tile_groups = table.deepcopy(gaia_tile_groups)

return planet_map_gen
