--====================================================================================================
--DECORATIVES FOR GAIA
--====================================================================================================

local gaia_biomes = require("gaia-biomes")
local tile_groups = gaia_biomes.tile_groups

local gaia_decorative_settings = {
    ["ei-gaia-green-carpet-grass"] = {frequency = 2.3, richness = 1, size = 1.6},
    ["ei-gaia-green-asterisk-mini"] = {frequency = 0.55, richness = 1, size = 0.7},
    ["ei-gaia-green-bush-mini"] = {frequency = 0.75, richness = 1, size = 0.8},
    ["ei-gaia-green-hairy-grass"] = {frequency = 1.95, richness = 1, size = 1.45},
    ["ei-gaia-lichen-decal"] = {frequency = 0.38, richness = 1, size = 0.65},
    ["ei-gaia-pink-lichen-decal"] = {frequency = 0.14, richness = 1, size = 0.42},
    ["ei-gaia-shroom-decal"] = {frequency = 0.22, richness = 1, size = 0.45},
    ["ei-gaia-tiny-rock"] = {frequency = 0.95, richness = 1, size = 1},
    ["ei-gaia-small-rock"] = {frequency = 0.55, richness = 1, size = 0.85},
    ["ei-gaia-tiny-rock-cluster"] = {frequency = 0.7, richness = 1, size = 0.9},
}

local function decorative_autoplace(base_autoplace, order, probability_expression, tile_restriction)
    local autoplace = base_autoplace and table.deepcopy(base_autoplace) or {}
    autoplace.order = order
    autoplace.probability_expression = probability_expression
    autoplace.tile_restriction = tile_restriction or tile_groups.land
    return autoplace
end

local function tint_pictures(decorative, tint)
    if not tint then
        return
    end

    for _, picture in ipairs(decorative.pictures or {}) do
        picture.tint = tint
    end
end

local function make_decorative(base_name, new_name, order, probability_expression, tile_restriction, tint)
    local decorative = data.raw["optimized-decorative"][base_name]
    if not decorative then
        error("Missing base decorative prototype: " .. base_name)
    end

    decorative = table.deepcopy(decorative)
    decorative.name = new_name
    decorative.autoplace = decorative_autoplace(decorative.autoplace, order, probability_expression, tile_restriction)
    tint_pictures(decorative, tint)

    data:extend({decorative})
end

make_decorative(
    "green-carpet-grass",
    "ei-gaia-green-carpet-grass",
    "a[landscape]-b[gaia]-a[meadow-carpet]",
    "clamp(0.02 + 0.14 * gaia_meadow_mask * (0.55 + gaia_lushness) * gaia_select(gaia_wetness, -1, 0.72, 0.2, 0.35, 1), 0, 0.19)",
    tile_groups.meadow,
    {r = 0.8, g = 1, b = 0.9}
)

make_decorative(
    "green-hairy-grass",
    "ei-gaia-green-hairy-grass",
    "a[landscape]-b[gaia]-b[wet-grass]",
    "clamp(0.008 + 0.11 * gaia_wet_mask * (0.4 + gaia_wetness) + 0.028 * gaia_meadow_mask * max(0, gaia_wetness - 0.42), 0, 0.18)",
    tile_groups.lush,
    {r = 0.82, g = 1, b = 0.92}
)

make_decorative(
    "green-bush-mini",
    "ei-gaia-green-bush-mini",
    "a[landscape]-b[gaia]-c[bush]",
    "clamp(0.003 + 0.022 * gaia_meadow_mask * gaia_lushness * max(0, gaia_accent_noise - 0.28), 0, 0.04)",
    tile_groups.meadow,
    {r = 0.83, g = 0.97, b = 0.9}
)

make_decorative(
    "green-asterisk-mini",
    "ei-gaia-green-asterisk-mini",
    "a[landscape]-b[gaia]-d[wet-asterisk]",
    "clamp(0.002 + 0.032 * gaia_wet_mask * max(0, gaia_accent_noise - 0.46), 0, 0.05)",
    tile_groups.wet,
    {r = 0.86, g = 1, b = 0.93}
)

make_decorative(
    "lichen-decal",
    "ei-gaia-lichen-decal",
    "a[landscape]-b[gaia]-e[lichen]",
    "clamp(0.0015 + 0.018 * gaia_wet_mask * gaia_rock_fringe_mask * max(0, gaia_accent_noise - 0.36), 0, 0.028)",
    tile_groups.lush,
    {r = 0.82, g = 1, b = 0.94}
)

make_decorative(
    "pink-lichen-decal",
    "ei-gaia-pink-lichen-decal",
    "a[landscape]-b[gaia]-f[pink-lichen]",
    "clamp(0.0004 + 0.008 * gaia_meadow_mask * max(0, gaia_accent_noise - 0.72), 0, 0.012)",
    tile_groups.meadow,
    {r = 0.87, g = 0.68, b = 0.72}
)

make_decorative(
    "shroom-decal",
    "ei-gaia-shroom-decal",
    "a[landscape]-b[gaia]-g[shroom]",
    "clamp(0.0005 + 0.01 * gaia_wet_mask * max(0, gaia_accent_noise - 0.68), 0, 0.014)",
    tile_groups.wet,
    {r = 0.93, g = 0.82, b = 1}
)

make_decorative(
    "tiny-rock",
    "ei-gaia-tiny-rock",
    "a[landscape]-c[rock]-a[tiny]",
    "clamp(0.012 + 0.075 * gaia_rock_fringe_mask + 0.05 * gaia_rock_core_mask, 0, 0.13)",
    tile_groups.rock
)

make_decorative(
    "small-rock",
    "ei-gaia-small-rock",
    "a[landscape]-c[rock]-b[small]",
    "clamp(0.004 + 0.022 * gaia_rock_fringe_mask + 0.032 * gaia_rock_core_mask, 0, 0.05)",
    tile_groups.rock
)

make_decorative(
    "tiny-rock-cluster",
    "ei-gaia-tiny-rock-cluster",
    "a[landscape]-c[rock]-c[cluster]",
    "clamp(0.003 + 0.025 * gaia_rock_fringe_mask + 0.017 * gaia_rock_core_mask, 0, 0.042)",
    tile_groups.rock
)

return gaia_decorative_settings
