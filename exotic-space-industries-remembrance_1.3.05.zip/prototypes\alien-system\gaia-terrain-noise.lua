data:extend({
    {
        type = "noise-function",
        name = "gaia_select",
        parameters = {"input", "from", "to", "slope", "min_value", "max_value"},
        expression = "clamp(min(input - (from - slope), to + slope - input) / slope, min_value, max_value)",
    },
    {
        type = "noise-expression",
        name = "gaia_starting_land",
        expression = "clamp(1 - distance / 260, 0, 0.85)",
    },
    {
        type = "noise-expression",
        name = "gaia_wobble_x",
        expression = "multioctave_noise{x = x, y = y, persistence = 0.7, seed0 = map_seed, seed1 = 1100, octaves = 3, input_scale = 1/140}",
    },
    {
        type = "noise-expression",
        name = "gaia_wobble_y",
        expression = "multioctave_noise{x = x, y = y, persistence = 0.7, seed0 = map_seed, seed1 = 1200, octaves = 3, input_scale = 1/140}",
    },
    {
        type = "noise-expression",
        name = "gaia_wobble_small_x",
        expression = "multioctave_noise{x = x, y = y, persistence = 0.72, seed0 = map_seed, seed1 = 1300, octaves = 2, input_scale = 1/45}",
    },
    {
        type = "noise-expression",
        name = "gaia_wobble_small_y",
        expression = "multioctave_noise{x = x, y = y, persistence = 0.72, seed0 = map_seed, seed1 = 1400, octaves = 2, input_scale = 1/45}",
    },
    {
        type = "noise-expression",
        name = "gaia_variant_noise",
        expression = "clamp(0.5 + 0.5 * multioctave_noise{x = x + gaia_wobble_x * 12, y = y + gaia_wobble_y * 12, persistence = 0.72, seed0 = map_seed, seed1 = 2100, octaves = 4, input_scale = 1/70}, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_forest_noise",
        expression = "clamp(0.5 + 0.32 * multioctave_noise{x = x + gaia_wobble_x * 18, y = y + gaia_wobble_y * 18, persistence = 0.7, seed0 = map_seed, seed1 = 2200, octaves = 4, input_scale = 1/210} + 0.18 * multioctave_noise{x = x + gaia_wobble_small_x * 8, y = y + gaia_wobble_small_y * 8, persistence = 0.72, seed0 = map_seed, seed1 = 2300, octaves = 2, input_scale = 1/85}, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_accent_noise",
        expression = "clamp(0.5 + 0.5 * multioctave_noise{x = x + gaia_wobble_x * 6, y = y + gaia_wobble_y * 6, persistence = 0.68, seed0 = map_seed, seed1 = 2400, octaves = 4, input_scale = 1/95}, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_landmass_large",
        expression = "0.65 + 0.35 * multioctave_noise{x = x, y = y, persistence = 0.7, seed0 = map_seed, seed1 = 3100, octaves = 4, input_scale = 1/950}",
    },
    {
        type = "noise-expression",
        name = "gaia_landmass_medium",
        expression = "0.5 + 0.5 * multioctave_noise{x = x + gaia_wobble_x * 40, y = y + gaia_wobble_y * 40, persistence = 0.68, seed0 = map_seed, seed1 = 3200, octaves = 4, input_scale = 1/260}",
    },
    {
        type = "noise-expression",
        name = "gaia_hilliness",
        expression = "clamp(0.5 + 0.5 * multioctave_noise{x = x + gaia_wobble_small_x * 18, y = y + gaia_wobble_small_y * 18, persistence = 0.7, seed0 = map_seed, seed1 = 3300, octaves = 4, input_scale = 1/120}, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_river_mask",
        expression = "clamp(1.08 - 3.2 * abs(multioctave_noise{x = x + gaia_wobble_x * 95 + gaia_wobble_small_x * 24, y = y + gaia_wobble_y * 95 + gaia_wobble_small_y * 24, persistence = 0.68, seed0 = map_seed, seed1 = 4100, octaves = 5, input_scale = 1/420}) + 0.12 * multioctave_noise{x = x + gaia_wobble_x * 40, y = y + gaia_wobble_y * 40, persistence = 0.7, seed0 = map_seed, seed1 = 4200, octaves = 2, input_scale = 1/140}, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_lake_mask",
        expression = "clamp((gaia_river_mask * (0.64 + 0.82 * lake_sites)) + (basin_noise * lake_sites * 0.72) - 0.08, 0, 1)",
        local_expressions = {
            lake_sites = "clamp(0.8 - 2.2 * abs(multioctave_noise{x = x + gaia_wobble_x * 80, y = y + gaia_wobble_y * 80, persistence = 0.7, seed0 = map_seed, seed1 = 4300, octaves = 3, input_scale = 1/720}), 0, 1)",
            basin_noise = "clamp(0.72 - 2.2 * abs(multioctave_noise{x = x + gaia_wobble_small_x * 20, y = y + gaia_wobble_small_y * 20, persistence = 0.72, seed0 = map_seed, seed1 = 4400, octaves = 3, input_scale = 1/220}), 0, 1)",
        },
    },
    {
        type = "noise-expression",
        name = "gaia_water_mask",
        expression = "clamp(max(gaia_river_mask * (0.88 + 0.8 * gaia_lake_mask), gaia_lake_mask * 1.08) - gaia_starting_land * 0.28, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_dry_macro",
        expression = "0.5 + 0.5 * multioctave_noise{x = x, y = y, persistence = 0.72, seed0 = map_seed, seed1 = 5100, octaves = 3, input_scale = 1/760}",
    },
    {
        type = "noise-expression",
        name = "gaia_rockiness",
        expression = "clamp(0.02 + 0.42 * gaia_dry_macro + 0.18 * multioctave_noise{x = x + gaia_wobble_x * 24, y = y + gaia_wobble_y * 24, persistence = 0.72, seed0 = map_seed, seed1 = 5200, octaves = 4, input_scale = 1/230} + 0.12 * gaia_hilliness - 0.22 * gaia_starting_land - 0.16 * gaia_river_mask - 0.12 * gaia_lake_mask, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_lushness",
        expression = "clamp(0.4 + 0.34 * multioctave_noise{x = x + gaia_wobble_x * 20, y = y + gaia_wobble_y * 20, persistence = 0.7, seed0 = map_seed, seed1 = 5300, octaves = 4, input_scale = 1/190} + 0.5 * gaia_river_mask + 0.42 * gaia_lake_mask - 0.55 * gaia_rockiness, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_elevation",
        expression = "max(-30, 7 + 15 * gaia_landmass_large + 7 * gaia_landmass_medium + 5 * gaia_hilliness - 56 * gaia_water_mask)",
    },
    {
        type = "noise-expression",
        name = "gaia_wetness",
        expression = "clamp(0.12 + 0.75 * gaia_river_mask + 0.9 * gaia_lake_mask + 0.18 * gaia_landmass_medium - 0.35 * gaia_rockiness - 0.18 * clamp(gaia_elevation / 36, 0, 1), 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_land_mask",
        expression = "clamp(gaia_elevation / 10, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_meadow_mask",
        expression = "clamp(gaia_select(gaia_lushness - gaia_wetness * 0.28, 0.28, 1.1, 0.18, 0, 1) * gaia_select(gaia_rockiness, -1, 0.7, 0.12, 0, 1) * gaia_land_mask, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_wet_mask",
        expression = "clamp(gaia_select(gaia_wetness, 0.28, 1.1, 0.14, 0, 1) * gaia_select(gaia_lushness, 0.2, 1.1, 0.16, 0, 1) * gaia_land_mask, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_rock_fringe_mask",
        expression = "clamp(gaia_select(gaia_rockiness, 0.46, 0.8, 0.14, 0, 1) * gaia_select(gaia_wetness, -1, 0.7, 0.18, 0, 1) * gaia_land_mask, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_rock_core_mask",
        expression = "clamp(gaia_select(gaia_rockiness, 0.78, 1.2, 0.12, 0, 1) * gaia_select(gaia_wetness, -1, 0.42, 0.18, 0, 1) * gaia_land_mask, 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_aux",
        expression = "clamp(aux_basic - 0.22 * gaia_wet_mask - 0.14 * gaia_meadow_mask + 0.04 * gaia_rock_fringe_mask + 0.18 * gaia_rock_core_mask + 0.06 * (gaia_variant_noise - 0.5), 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_moisture",
        expression = "clamp(moisture_basic + 0.26 * gaia_wet_mask + 0.14 * gaia_meadow_mask + 0.06 * gaia_rock_fringe_mask - 0.18 * gaia_rock_core_mask + 0.05 * (gaia_wetness - 0.5) + 0.02 * (gaia_forest_noise - 0.5), 0, 1)",
    },
    {
        type = "noise-expression",
        name = "gaia_temperature",
        expression = "clamp(temperature_basic - 3.4 * gaia_wet_mask - 2.6 * gaia_meadow_mask + 2.2 * gaia_rock_fringe_mask + 5.8 * gaia_rock_core_mask + 0.8 * (gaia_variant_noise - 0.5), 8, 32)",
    },
    {
        type = "noise-expression",
        name = "gaia_cliffiness",
        expression = "clamp((0.2 * cliffiness_basic + 0.9 * gaia_rock_core_mask + 0.45 * gaia_rock_fringe_mask) * gaia_select(gaia_elevation, 22, 90, 18, 0, 1) * gaia_select(gaia_wetness, -1, 0.52, 0.16, 0, 1), 0, 1)",
    },
})
