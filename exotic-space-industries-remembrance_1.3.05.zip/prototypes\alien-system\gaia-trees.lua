--====================================================================================================
--TREES FOR GAIA
--====================================================================================================

local gaia_biomes = require("gaia-biomes")

local function merge_tile_groups(...)
    local merged = {}

    for i = 1, select("#", ...) do
        for _, tile_name in ipairs(select(i, ...)) do
            merged[#merged + 1] = tile_name
        end
    end

    return merged
end

local gaia_meadow_tiles = gaia_biomes.tile_groups.meadow
local gaia_wet_tiles = gaia_biomes.tile_groups.wet
local gaia_edge_tiles = merge_tile_groups(gaia_biomes.tile_groups.lush, gaia_biomes.tile_groups.rock_fringe)

-- Tree colors multiply the leaf sprite. Gaia leaf sheets are already custom-colored,
-- so these tints need to stay bright or the canopy collapses into a dark silhouette.
local tree_colors = {
    ["01"] = {
        {r = 214, g = 255, b = 224},
        {r = 198, g = 246, b = 232},
        {r = 184, g = 236, b = 246},
        {r = 206, g = 255, b = 236},
        {r = 192, g = 240, b = 214},
        {r = 176, g = 228, b = 206},
        {r = 162, g = 220, b = 226},
        {r = 226, g = 255, b = 242},
    },
    ["02"] = {
        {r = 212, g = 244, b = 255},
        {r = 224, g = 234, b = 255},
        {r = 198, g = 255, b = 246},
        {r = 232, g = 220, b = 255},
        {r = 188, g = 230, b = 255},
        {r = 210, g = 255, b = 255},
        {r = 242, g = 228, b = 255},
        {r = 180, g = 220, b = 248},
    },
    ["05"] = {
        {r = 255, g = 226, b = 200},
        {r = 255, g = 236, b = 214},
        {r = 255, g = 220, b = 194},
        {r = 246, g = 214, b = 188},
        {r = 255, g = 244, b = 220},
        {r = 255, g = 230, b = 212},
        {r = 242, g = 220, b = 194},
        {r = 255, g = 242, b = 232},
    },
}

local function gaia_leaf_filename(filename)
    local remapped = filename:gsub("^__base__/graphics/entity/tree/", ei_graphics_tree_path)
    remapped = remapped:gsub("/tree%-", "/hr-tree-")
    return remapped
end

local function gaia_tree_probability(number)
    if number == "01" then
        return "clamp(0.002 + 0.038 * max(0, gaia_forest_noise - 0.16) * gaia_meadow_mask * (0.75 + 0.55 * gaia_lushness), 0, 0.068)"
    end

    if number == "02" then
        return "clamp(0.002 + 0.044 * max(0, gaia_forest_noise - 0.12) * gaia_wet_mask * (0.8 + 0.6 * gaia_wetness), 0, 0.075)"
    end

    return "clamp(0.0008 + 0.02 * max(0, gaia_forest_noise - 0.28) * max(0.55 * gaia_meadow_mask, 0.85 * gaia_rock_fringe_mask, 0.45 * gaia_wet_mask) * (0.65 + 0.35 * gaia_lushness), 0, 0.028)"
end

local function make_tree(number, tile_restriction)
    local tree = table.deepcopy(data.raw.tree["tree-" .. number])
    tree.name = "ei-gaia-tree-" .. number
    tree.autoplace = {
        order = "a[tree]-b[forest]-gaia",
        probability_expression = gaia_tree_probability(number),
        tile_restriction = tile_restriction,
    }
    tree.colors = tree_colors[number]

    for i, variation in ipairs(tree.variations) do
        tree.variations[i].leaves.filename = gaia_leaf_filename(variation.leaves.filename)
    end

    data:extend({tree})
end

make_tree("01", gaia_meadow_tiles)
make_tree("02", gaia_wet_tiles)
make_tree("05", gaia_edge_tiles)
