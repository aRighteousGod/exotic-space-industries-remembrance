--====================================================================================================
--MAIN CONTENT CODE
--====================================================================================================

-- prototype definitions for buildable entities get seperate files
-- those include prototype definitions for recipes, items, techs and categories

-- add alien beacon
require("alien-beacon")
-- add alien stabilizer
require("alien-stabilizer")
-- add shared Gaia terrain noise
require("gaia-terrain-noise")
-- add new tiles
require("gaia-tiles")
-- add new trees
require("gaia-trees")
-- add Gaia decoratives
require("gaia-decoratives")
-- add Gaia boulders
require("gaia-boulders")
-- add gate
require("gate")
-- add crystal accumulator
require("crystal-accumulator")
-- add farsation
require("farstation")
-- add other
require("alien-structures")
-- add other
require("gaia-planet")
