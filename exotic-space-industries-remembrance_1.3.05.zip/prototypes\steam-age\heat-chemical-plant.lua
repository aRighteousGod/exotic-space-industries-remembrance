ei_lib = require("lib/lib")

--====================================================================================================
--HEAT CHEM PLANT
--====================================================================================================

data:extend({
    {
        name = "ei-heat-chemical-plant",
        type = "item",
        icon = ei_graphics_item_path.."heat-chemical-plant.png",
        icon_size = 64,
        icon_mipmaps = 4,
        subgroup = "production-machine",
        order = "e",
        place_result = "ei-heat-chemical-plant",
        stack_size = 50
    },
    {
        name = "ei-heat-chemical-plant",
        type = "recipe",
        category = "crafting",
        energy_required = 2,
        ingredients =
        {
            {type="item", name="pipe", amount=4},
            {type="item", name="steel-plate", amount=3},
            {type="item",name="ei-steel-beam",amount=3},
            {type="item", name="ei-copper-mechanical-parts", amount=4},
            {type="item", name="stone-furnace", amount=1},
        },
        results = {{type="item", name="ei-heat-chemical-plant", amount=1}},
        enabled = false,
        always_show_made_in = true,
        main_product = "ei-heat-chemical-plant",
    }
})

local plant = table.deepcopy(data.raw["assembling-machine"]["chemical-plant"])
plant.name = "ei-heat-chemical-plant"
plant.icon = ei_graphics_item_path.."heat-chemical-plant.png"
plant.icon_size = 64
plant.minable.result = "ei-heat-chemical-plant"
plant.fast_replaceable_group = "chemical-plant"
plant.next_upgrade = "chemical-plant"
plant.energy_usage = "1MW"
plant.heating_energy = "100kW"
plant.crafting_speed = 1.5
table.insert(plant.crafting_categories,"ei-burning")
plant.graphics_set = {
  animation = ei_lib.make_4way_animation_from_spritesheet({ layers =
  {
    {
      filename = ei_graphics_entity_path.."hr-heat-chemical-plant.png",
      width = 220,
      height = 292,
      frame_count = 24,
      line_length = 12,
      shift = util.by_pixel(0.5, -9),
      scale = 0.5
    },
    {
      filename = "__base__/graphics/entity/chemical-plant/chemical-plant-shadow.png",
      width = 312,
      height = 222,
      repeat_count = 24,
      frame_count = 1,
      shift = util.by_pixel(27, 6),
      draw_as_shadow = true,
      scale = 0.5
    }
  }})
}

plant.energy_source = {
    type = 'heat',
    max_temperature = 275,
    min_working_temperature = 185,
    specific_heat = ei_data.specific_heat,
    max_transfer = '10MW',
    emissions_per_minute={pollution=5},
    connections = {
        {position = {-1.3, 0}, direction = defines.direction.west},
        -- {position = {0,1.4}, direction = defines.direction.south},
        {position = {1.3, 0}, direction = defines.direction.east},
        -- {position = {-1.5,0}, direction = defines.direction.west}
    }
}

data:extend({plant})

