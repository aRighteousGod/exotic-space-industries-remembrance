local gaia_planet = game.planets["gaia"]
if not gaia_planet then
    return
end

local gaia_surface = gaia_planet.surface
if gaia_surface and gaia_surface.valid then
    return
end

local legacy_surface = game.surfaces["Gaia"]
if not legacy_surface or not legacy_surface.valid then
    return
end

gaia_planet:associate_surface(legacy_surface)
